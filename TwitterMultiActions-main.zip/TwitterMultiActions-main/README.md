# TwitterMultiActions

### Установка:

\# переносим все файлы в папку, в пути не должно быть кириллицы и пробелов

1. win+r -> cmd
2. cd /d ДиректорияСоСкриптом
ex: cd /d C\:TwitterMultiActions
3. pip install -r requirements.txt
4. python TwitterMultiActionsV2.py

В accounts.txt вписываем куки от аккаунтов, каждый с новой строки
Берем их из F12 в браузере и вкладки Network (само слово 'cookie' копировать не нужно)

Если прокси будут не работать - пробуйте менять тип прокси (с https на http)
